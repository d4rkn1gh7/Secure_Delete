import os
import random
MAX_LIMIT = 255


def secure_delete(path, passes=3):
    with open(path, "ba+", buffering=0) as delfile:
        length = delfile.tell()
    delfile.close()
    with open(path, "br+", buffering=0) as delfile:
        #print("Length of file:%s" % length)
        for i in range(passes):
            delfile.seek(0,0)
            delfile.write(os.urandom(length))

        delfile.seek(0)
        for x in range(length):
            delfile.write(b'\x00')
        
        delfile.close()
        os.remove(path)


def generate_file():
    with open("random_file.txt","w") as random_file:
        for _ in range(500):
            random_integer = random.randint(97, 97 + 26 - 1)
            flip_bit = random.randint(0, 1)
    # Convert to lowercase if the flip bit is on
            random_integer = random_integer - 32 if flip_bit == 1 else random_integer
    # Keep appending random characters using chr(x)
            random_file.write(chr(random_integer))

generate_file()

secure_delete("C:/Users/Balaji Anandhan/Testing-Delete/random_file.txt",5)



